Bootstrap Pricing Slider
========================

## Description
Bootstrap Pricing Slider

## Website Development
+ [http://amirolahmad.github.io/bootstrap-pricing-slider/](http://amirolahmad.github.io/bootstrap-pricing-slider/)

## Authors
+ [https://twitter.com/amirolahmad](https://twitter.com/amirolahmad)

## Copyright and license
Copyright 2013 Instajob under [the Apache 2.0 license](LICENSE).